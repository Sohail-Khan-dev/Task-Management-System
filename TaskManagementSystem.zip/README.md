This is Task Managemet System. Where admin can create a task .
Password for Admin is 123456
