@extends('layouts.Mainlayout')  
@section('title','Login') 
<!-- @section('projectName')
  <h1 class="text-center font-bold text-2xl bg-gray-200">  User Login Form </h1>
@endsection -->
@section('main-content')
<livewire:login-user/>

@endsection
