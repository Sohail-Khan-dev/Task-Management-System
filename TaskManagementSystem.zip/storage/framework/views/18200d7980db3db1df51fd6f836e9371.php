<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
        <!-- Include Alpine.js (if not already included) -->
        <script src="//unpkg.com/alpinejs" defer></script>

       <title><?php echo $__env->yieldContent('title','Task Management System'); ?> </title>
    </head>
    <body class="flex flex-col min-h-screen">
        <header>
            <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </header>
        <!-- Showing This on each Page. -->
        <!-- <?php $__env->startSection('projectName'); ?>  
            <h1 class="text-xl text-center font-bold ml-32 bg-gray-200 py-4">Task Management System</h1>
        <?php echo $__env->yieldSection(); ?>     -->
        <main class="flex-grow max-h-screen bg-gray-200 <?php echo $__env->yieldPushContent('main-class'); ?>">
        <?php echo $__env->yieldContent('main-content'); ?>
        </main>
    <footer>
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </footer>
    <script>
        Livewire.on('loggedOut', function() {
            window.location.href = '/home';
        });
    </script>

    </body>
</html><?php /**PATH E:\Laravel-Projects\TaskManagementSystem\resources\views/layouts/Mainlayout.blade.php ENDPATH**/ ?>