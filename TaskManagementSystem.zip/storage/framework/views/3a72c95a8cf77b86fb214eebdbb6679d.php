

<?php $__env->startSection('title','Color Theme'); ?>

<?php $__env->startSection('main-content'); ?>
<div class="bg-gray-100 text-gray-800">
   <?php $__env->startSection('projectName'); ?>
        <header class="bg-blue-500 text-white">
        <h1>Your Task Management System</h1>
    </header>

    <button class="bg-blue-500 text-white hover:bg-blue-600">
        Primary Action
    </button>

    <button class="bg-blue-300 text-white hover:bg-blue-400">
        Secondary Action
    </button>

    <div class="alert bg-red-400 text-white">
        Important Alert
    </div>

    <div class="p-4 border border-gray-300 shadow-md">
        <p>Task details...</p>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-Projects\TaskManagementSystem\resources\views/temp/theme.blade.php ENDPATH**/ ?>