
<?php $__env->startSection('title','All Users'); ?>
<?php $__env->startSection('main-content'); ?>
<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('task-manager', []);

$__html = app('livewire')->mount($__name, $__params, 'qAkvNDg', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-Projects\TaskManagementSystem\resources\views/Task/index.blade.php ENDPATH**/ ?>