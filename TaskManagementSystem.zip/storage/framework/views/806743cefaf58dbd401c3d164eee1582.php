  
<script>
  Livewire.on('userRegistered', function() {
    print('successfully Registed ');
    window.location.href = '/task';
  });
</script>
<?php $__env->startSection('title','Register'); ?> 
<!-- <?php $__env->startSection('projectName'); ?>
  <h1 class="text-center font-bold text-2xl bg-gray-200 py-4">  User Registration Form </h1>
<?php $__env->stopSection(); ?> -->
<?php $__env->startSection('main-content'); ?>
<?php if($user): ?>
  <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('register-user', ['user' => $user]);

$__html = app('livewire')->mount($__name, $__params, 'FsHnhPW', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
  <?php else: ?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('register-user', []);

$__html = app('livewire')->mount($__name, $__params, 'HrqkD1e', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-Projects\TaskManagementSystem\resources\views/User/register.blade.php ENDPATH**/ ?>