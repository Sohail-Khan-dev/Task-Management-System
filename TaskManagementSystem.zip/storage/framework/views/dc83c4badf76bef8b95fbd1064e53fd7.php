  
<?php $__env->startSection('title','Login'); ?> 
<!-- <?php $__env->startSection('projectName'); ?>
  <h1 class="text-center font-bold text-2xl bg-gray-200">  User Login Form </h1>
<?php $__env->stopSection(); ?> -->
<?php $__env->startSection('main-content'); ?>
<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('login-user', []);

$__html = app('livewire')->mount($__name, $__params, 'hteQY7X', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-Projects\TaskManagementSystem\resources\views/User/login.blade.php ENDPATH**/ ?>